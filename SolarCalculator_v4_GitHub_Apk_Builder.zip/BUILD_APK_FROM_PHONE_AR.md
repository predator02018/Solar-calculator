# Solar Calculator v4 - بناء APK من الهاتف

هذه النسخة تحتوي على إعداد GitHub Actions لبناء ملف APK تلقائياً.

## الطريقة المختصرة من الهاتف

1. أنشئ مستودعاً جديداً على GitHub، مثلاً:
   `solar-calculator`
2. فك ضغط هذا الملف على الهاتف.
3. افتح المستودع في GitHub من المتصفح.
4. اختر **Add file → Upload files**.
5. ارفع ملفات المشروع والمجلدات الموجودة داخله، بما فيها:
   `.github/workflows/build-apk.yml`
6. اعمل Commit إلى فرع `main`.
7. افتح تبويب **Actions** في المستودع.
8. اختر **Build Android APK**.
9. بعد نجاح البناء افتح التشغيل الناجح ثم قسم **Artifacts**.
10. نزّل `SolarCalculator-debug` وستجد داخله:
    `app-debug.apk`

ملف APK الناتج هو نسخة Debug مخصصة للتجربة على الهاتف.

ملاحظة:
- لا تحتاج إلى كمبيوتر أو Android Studio.
- GitHub هو الذي سيشغل بيئة البناء ويثبت Java/Gradle ثم يبني APK.
