package com.example.solarcalculator;
import android.app.*; import android.os.*; import android.graphics.Color; import android.text.InputType; import android.view.Gravity; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root; EditText monthly,nightLoad,nightHours,sun,panel,pVoc,pVmp,pIsc,pImp,bv,bah,dod,mppt,be,ie,ce,reserve,autonomy,inv,mpptVmin,mpptVmax;
 TextView result;
 EditText f(String h,String x){ EditText e=new EditText(this);e.setHint(h);e.setText(x);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setPadding(16,9,16,9);root.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 double v(EditText e,double d){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return d;}}
 int ceil(double x){return (int)Math.ceil(x);}
 void sec(String s){TextView t=new TextView(this);t.setText("\n"+s);t.setTextSize(19);t.setTextColor(Color.rgb(20,80,130));root.addView(t);}
 @Override public void onCreate(Bundle b){super.onCreate(b);ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(26,20,26,28);sc.addView(root);setContentView(sc);
  TextView t=new TextView(this);t.setText("☀️ حاسبة المنظومة الشمسية — الإصدار 3.0");t.setTextSize(24);t.setGravity(Gravity.CENTER);t.setTextColor(Color.rgb(20,80,130));root.addView(t);
  TextView q=new TextView(this);q.setText("حساب الألواح والبطاريات والتوالي والتوازي وMPPT");q.setGravity(Gravity.CENTER);root.addView(q);
  sec("الاستهلاك الليلي"); monthly=f("الاستهلاك الشهري (kWh)","600"); nightLoad=f("متوسط الحمل بعد الغروب (W)","1000"); nightHours=f("ساعات التشغيل بعد الغروب","12");
  sec("الشمس واللوح"); sun=f("ساعات الشمس الفعالة يومياً","5"); panel=f("قدرة اللوح (W)","550"); pVoc=f("Voc للوح (V)","49.5"); pVmp=f("Vmp للوح (V)","41.5"); pIsc=f("Isc للوح (A)","14"); pImp=f("Imp للوح (A)","13.25");
  sec("البطارية"); bv=f("جهد البطارية (V)","48"); bah=f("سعة البطارية (Ah)","200"); dod=f("DoD (%)","80"); autonomy=f("أيام الاستقلالية الإضافية","1");
  sec("الكفاءة والاحتياط"); mppt=f("كفاءة MPPT (%)","98"); be=f("كفاءة البطارية (%)","95"); ie=f("كفاءة الانفرتر (%)","92"); ce=f("كفاءة الكابلات (%)","98"); reserve=f("احتياط التصميم (%)","10");
  sec("الانفرتر و MPPT"); inv=f("قدرة الانفرتر/الهايبر (W)","5000"); mpptVmin=f("أقل جهد MPPT (V)","120"); mpptVmax=f("أعلى جهد MPPT (V)","450");
  Button c=new Button(this);c.setText("احسب المنظومة");root.addView(c);result=new TextView(this);result.setTextSize(17);result.setPadding(16,16,16,16);root.addView(result);c.setOnClickListener(x->calc());
 }
 void calc(){
  double m=v(monthly,600),nl=v(nightLoad,1000),nh=v(nightHours,12),sh=v(sun,5),pw=v(panel,550);
  double voc=v(pVoc,49.5),vmp=v(pVmp,41.5),isc=v(pIsc,14),imp=v(pImp,13.25);
  double bv0=v(bv,48),ah=v(bah,200),d=v(dod,80)/100,me=v(mppt,98)/100,be0=v(be,95)/100,ie0=v(ie,92)/100,ce0=v(ce,98)/100,r=1+v(reserve,10)/100;
  double daily=m/30,night=nl*nh/1000,batK=bv0*ah/1000,needNight=night/(d*be0*ie0)*r;
  int bats=ceil(needNight/batK), totalK=bats;
  double pvNeed=daily/(me*ie0*ce0)*r; int panels=ceil(pvNeed*1000/(pw*sh));
  double reqInv=nl/ie0*1.25;
  double vMin=v(mpptVmin,120),vMax=v(mpptVmax,450);
  int seriesByVmp=(int)Math.floor(vMax/vmp); if(seriesByVmp<1)seriesByVmp=1;
  int minSeries=(int)Math.ceil(vMin/vmp);
  int series=Math.max(1,minSeries); if(series>seriesByVmp) series=seriesByVmp;
  int parallel=ceil((double)panels/series); int actual=series*parallel;
  double stringVmp=series*vmp,stringVoc=series*voc,arrayImp=parallel*imp,arrayIsc=parallel*isc;
  String mpptWarn=(stringVoc>vMax)?"⚠️ Voc السلسلة أعلى من حد MPPT!":(stringVmp<vMin)?"⚠️ Vmp السلسلة أقل من بداية MPPT!":"✅ جهد السلسلة ضمن نطاق MPPT المدخل";
  // Battery series/parallel for a 48V bank; if battery voltage differs, compute needed series count.
  int bSeries=Math.max(1,(int)Math.ceil(bv0/48.0)); int bParallel=ceil((double)bats/bSeries); int bActual=bSeries*bParallel;
  double bankV=bSeries*bv0,bankAh=bParallel*ah;
  result.setText(String.format(Locale.US,
   "النتيجة المقترحة\\n\\n☀️ الألواح: %d لوح فعلي (%d لوح محسوب) × %.0fW\\nإجمالي القدرة: %.2f kW\\n\\n"+
   "🔗 توصيل الألواح المقترح: %d على التوالي × %d توازي = %d لوح\\n"+
   "Vmp للسلسلة: %.1fV | Voc للسلسلة: %.1fV\\nImp للمصفوفة: %.2fA | Isc للمصفوفة: %.2fA\\n%s\\n\\n"+
   "🔋 البطاريات: %d بطارية على الأقل\\nتكوين تقريبي لبنك 48V: %d توالي × %d توازي = %d بطارية\\nجهد البنك: %.0fV | سعة البنك: %.0fAh\\nالتخزين الاسمي: %.2f kWh\\n\\n"+
   "🌙 استهلاك الليل: %.2f kWh خلال %.1f ساعة\\nمدة التشغيل التقديرية للحمل الليلي تعتمد على DoD والكفاءات\\n\\n"+
   "⚡ الانفرتر المقترح للحمل الليلي: %.0fW أو أعلى\\n\\n"+
   "⚙️ MPPT: نطاق الإدخال المدخل %.0f–%.0fV\\n\\nملاحظة: الحسابات أولية. يجب مطابقة Voc مع أقل درجة حرارة، وحدود MPPT، وتيار الألواح والبطاريات مع مواصفات الجهاز الفعلية قبل التنفيذ.",
   actual,panels,pw,actual*pw/1000,series,parallel,actual,stringVmp,stringVoc,arrayImp,arrayIsc,mpptWarn,
   bats,bSeries,bParallel,bActual,bankV,bankAh,bActual*batK,night,nh,reqInv,vMin,vMax));
 }
}